/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readfile;

import com.opencsv.CSVWriter;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author ashishdass
 */
public class ReadFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        BufferedReader br1 = new BufferedReader(new FileReader("input_to_mahout_helper.csv"));
        Map<String, List<TrackCount>> mymap = new HashMap<String, List<TrackCount>>();
        Map<String, Integer> songsmap = new HashMap<String,Integer>();
        Map<String, Integer> usersmap = new HashMap<String,Integer>();
        Map<Integer, List<TrackCount>> finalmap = new HashMap<Integer, List<TrackCount>>();
        int counterOfUsers=1;
        int counterOfSongs=1;
        String line = br1.readLine();
        //int hash = 7;
        //int hash1 = 7;
        while(line !=null){
            //System.out.println(" "+line);
            String[] linecontents = line.split(",");
            
            if(songsmap.containsKey(linecontents[1])){
            }
            else{
                songsmap.put(linecontents[1], counterOfSongs);
                counterOfSongs++;
            }
            
            if(usersmap.containsKey(linecontents[0])){
            }
            else{
                usersmap.put(linecontents[0], counterOfUsers);
                counterOfUsers++;
            }
            
            if(mymap.get(linecontents[0]) != null){
                List<TrackCount> local = mymap.get(linecontents[0]);
                TrackCount tc= new TrackCount(linecontents[1], Integer.parseInt(linecontents[2]));
                local.add(tc);
                mymap.put(linecontents[0],local);
            
            }
            else{
                List<TrackCount> local = new ArrayList<>();
                TrackCount tc= new TrackCount(linecontents[1], Integer.parseInt(linecontents[2]));
                local.add(tc);
                //local.add(linecontents[1]);
                mymap.put(linecontents[0],local );
            }
            
            line = br1.readLine();
        
        }
        
        for (String name: mymap.keySet()){

            //String key =name.toString();
            if(usersmap.get(name) !=null){
            
                int usernum=usersmap.get(name);
                List<TrackCount> tempsonglist = new ArrayList();
                List<TrackCount> valuelist = mymap.get(name);
                for(int i=0;i<valuelist.size();i++){
                    TrackCount s =  valuelist.get(i);
                    String currvalue=songsmap.get(s.getTrackId()).toString();
                    int countnow =s.getPlayCount();
                    TrackCount newTC = new TrackCount(currvalue,countnow);
                    tempsonglist.add(newTC);
            }
                
                finalmap.put(usernum, tempsonglist);
                //System.out.println(name + " " + valuelist.toString());
            }
        }
        
        
        
        String csv = "output.csv";
        CSVWriter writer = new CSVWriter(new FileWriter(csv));
        
        
        for (Integer name: finalmap.keySet()){
            
            List<TrackCount> value = finalmap.get(name);
            
            String[] currentRecord = new String[value.size()+2];
            
            for (TrackCount retval: value) {
                currentRecord[0]= String.valueOf(name);
            currentRecord[1] = retval.getTrackId();
            currentRecord[2] = String.valueOf(retval.getPlayCount());
                    // System.out.println(String.valueOf(name)+","+retval);

            writer.writeNext(currentRecord);
      }
            
            //System.out.println(" key  " + name + " value " +value.toString() );
        
        }
        
        
        
        //Create record
        //String [] record = "4,David,Miller,Australia,30".split(",");
        
        //Write the record to file
        //writer.writeNext(record);

        //close the writer
        writer.close();
         
        
        
        
    }
    
}
