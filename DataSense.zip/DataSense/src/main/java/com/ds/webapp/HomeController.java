package com.ds.webapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import org.jmusixmatch.MusixMatch;
import org.jmusixmatch.MusixMatchException;
import org.jmusixmatch.entity.lyrics.Lyrics;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.watson.developer_cloud.tone_analyzer.v3.ToneAnalyzer;
import com.ibm.watson.developer_cloud.tone_analyzer.v3.model.ToneAnalysis;
import com.ibm.watson.developer_cloud.tradeoff_analytics.v1.model.Solution;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 * @throws JSONException 
	 * @throws IOException 
	 * @throws MusixMatchException 
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) throws IOException, JSONException, MusixMatchException {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);
		// tone analyzer
		ToneAnalyzer service = new ToneAnalyzer(ToneAnalyzer.VERSION_DATE_2016_05_19);
		service.setUsernameAndPassword("1a544dc1-f215-4e5d-be91-c2472da6a454", "lkzxQh6wKbXn");

		String text = "I am super excited";
		// Call the service and get the tone
		ToneAnalysis tone = service.getTone(text, null).execute();
		
		System.out.println("tone analysis "+tone);
		
		/*
		//weather api
		String url = "http://api.apixu.com/v1/current.json?key=63fed499542f48d5877161640171904&q=Miami";
		String jsonString = callURL(url);
		System.out.println("\n\njsonString: " + jsonString);
 
		// Replace this try catch block for all below subsequent examples
		try {  
			JSONArray jsonArray = new JSONArray(jsonString);
			System.out.println("\n\nWeather: " + jsonArray);
		} catch (JSONException e) {
			e.printStackTrace();
		} 
        //return new ModelAndView("redirect:" + "http://api.apixu.com/v1/current.json?key=63fed499542f48d5877161640171904&q=Paris");
*/

		//musixmatch API
		
		
		String mmApiKey = "69acc0e1db9665b7a345a4d23a0e1da5";
		MusixMatch musixMatch = new MusixMatch(mmApiKey);
		int trackID = 15953433;

		Lyrics lyrics = musixMatch.getLyrics(trackID);
		//System.out.println("try");
		System.out.println("track id" +trackID);
		System.out.println("Lyrics ID       : "     + lyrics.getLyricsId());
		System.out.println("Lyrics Language : "     + lyrics.getLyricsLang());
		System.out.println("Lyrics Body     : "     + lyrics.getLyricsBody());
		System.out.println("Script-Tracking-URL : " + lyrics.getScriptTrackingURL());
		//System.out.println("Pixel-Tracking-URL : "  + lyrics.getPixelTrackingURL());
		//System.out.println("Lyrics Copyright : "    + lyrics.getLyricsCopyright());
		
		//get lyrics tone
		
		
		System.out.println("tone of lyrics");
		String lyricsText=lyrics.getLyricsBody();
		//System.out.println("index before"+lyricsText.indexOf('\n'));
		String replacedLyrics = lyricsText.replace('\n', ' ');
		//System.out.println("index after"+replacedLyrics.indexOf('\n'));
		tone = service.getTone(replacedLyrics.trim(), null).execute();		
		System.out.println(tone);
		
		String toneString=tone.toString();
		System.out.println(toneString);
			
		//get final score of lyrics
		JsonParser jsonParser = new JsonParser();
              
       JsonObject tonej = (JsonObject) jsonParser.parse(toneString);
       JsonObject doc_tone = (JsonObject) tonej.get("document_tone");
       JsonArray tone_categories = (JsonArray) doc_tone.get("tone_categories");
       JsonObject emotionTone=(JsonObject)tone_categories.get(0);
       JsonArray tones = (JsonArray) emotionTone.get("tones");
       Map<String,Double> scoreTones=new HashMap<String,Double>();
       double sum=0.0;
       for (int i = 0; i < tones.size(); i++) {
           JsonObject toneObj = (JsonObject) tones.get(i);
           JsonElement tone_name = toneObj.get("tone_name");
           JsonElement score = toneObj.get("score");
           scoreTones.put(tone_name.toString(),score.getAsDouble());           
           sum+=score.getAsDouble();
       }
       double avg=sum/tones.size();
       System.out.println("avg"+avg);
       Iterator it = scoreTones.entrySet().iterator();
       
       double finalScore=0.0;
       it = scoreTones.entrySet().iterator();
       while(it.hasNext()){
             Map.Entry pair = (Map.Entry)it.next();
             double newValue=(Double)pair.getValue()/avg;
             scoreTones.put((String) pair.getKey(),newValue );
             if(newValue>finalScore)
                 finalScore=newValue;
       }
                      it = scoreTones.entrySet().iterator();

       while(it.hasNext()){
             Map.Entry pair = (Map.Entry)it.next();
             if(finalScore==(Double)pair.getValue()){
               System.out.println("Tone"+pair.getKey()+"score:"+finalScore);
               break;
             }
       }

		
		



		return "home";
	}
	
	
	
	public static String callURL(String myURL) {
		System.out.println("Requested URL:" + myURL);
		StringBuilder sb = new StringBuilder();
		URLConnection urlConn = null;
		InputStreamReader in = null;
		try {
			URL url = new URL(myURL);
			urlConn = url.openConnection();
			if (urlConn != null)
				urlConn.setReadTimeout(60 * 1000);
			if (urlConn != null && urlConn.getInputStream() != null) {
				
				in = new InputStreamReader(urlConn.getInputStream(),
						Charset.defaultCharset());
				BufferedReader bufferedReader = new BufferedReader(in);
				if (bufferedReader != null) {
					int cp;
					while ((cp = bufferedReader.read()) != -1) {
						sb.append((char) cp);
					}
					bufferedReader.close();
				}
			}
		in.close();
		} catch (Exception e) {
			throw new RuntimeException("Exception while calling URL:"+ myURL, e);
		} 
 
		return sb.toString();
	}
 
}


